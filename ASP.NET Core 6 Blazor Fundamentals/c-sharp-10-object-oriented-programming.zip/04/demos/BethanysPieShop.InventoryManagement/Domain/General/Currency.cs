﻿namespace BethanysPieShop.InventoryManagement.Domain.General
{
    public enum Currency
    {
        Dollar,
        Euro,
        Pound
    }
}
