﻿namespace BethanysPieShop.InventoryManagement.Domain.ProductManagement
{
    public enum UnitType
    {
        PerItem,
        PerBox,
        PerKg
    }
}
